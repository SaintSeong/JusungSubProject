만약 FileZilla Server에서 파일을 압축해야 한다면, MFC Cftpconnection 클래스를 사용하여 다음과 같은 방법으로 압축 명령을 실행할 수 있습니다:

1. 서버에 로그인하여 필요한 디렉토리로 이동합니다.
2. 압축할 파일의 확장자에 따라 압축 명령을 선택합니다. 예를 들어, "zip -r compressed_file.zip *.txt"는 현재 디렉토리의 모든 .txt 파일을 ZIP 파일로 압축합니다.
3. Cftpconnection::SendCommand 함수를 사용하여 압축 명령을 서버에 전송합니다.
4. Cftpconnection::GetLastError 함수를 사용하여 압축 프로세스 중 발생한 오류를 확인합니다.

CInternetSession session;
CInternetConnection* pConnection = session.GetFtpConnection("ftp.example.com", "username", "password");

if (pConnection != NULL)
{
   // 압축할 파일이 있는 디렉토리로 이동
   pConnection->SetCurrentDirectory("/path/to/files");

   // 서버에서 ZIP으로 압축 명령 실행
   BOOL bResult = pConnection->SendCommand("zip -r compressed_file.zip *.txt");

   if (bResult)
   {
      // 압축 성공
      AfxMessageBox("파일이 성공적으로 압축되었습니다!");
   }
   else
   {
      // 압축 실패
      DWORD dwError = pConnection->GetLastError();
      CString strError;
      strError.Format("오류 코드 %d로 압축 실패", dwError);
      AfxMessageBox(strError);
   }

   pConnection->Close();
   delete pConnection;
}
else
{
   // 연결 실패
   AfxMessageBox("FTP 서버에 연결하지 못했습니다!");
}


#include <bit7z/bit7z.hpp>
#include <iostream>

int main() {
  bit7z::Compressor compressor;

  // 폴더를 압축합니다.
  const std::string sourceFolderPath = "/path/to/folder";
  const std::string compressedFilePath = "compressed.7z";
  compressor.compress(sourceFolderPath, compressedFilePath);

  return 0;
}

#include <bit7z/bit7z.hpp>
#include <iostream>

int main() {
  bit7z::Compressor compressor;

  // 파일을 압축합니다.
  const std::string sourceFilePath = "file_to_compress.txt";
  const std::string compressedFilePath = "compressed.7z";
  compressor.compress(sourceFilePath, compressedFilePath);

  return 0;
}
