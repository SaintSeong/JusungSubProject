// MFC File compress use zlib 
#include <afx.h>
#include <zlib.h>

void CompressFile(CString strFilePath)
{
    // 압축할 파일 열기
    CFile file(strFilePath, CFile::modeRead);

    // 압축 파일 생성
    gzFile gzfile = gzopen("compressed.gz", "wb");

    // 데이터를 압축 파일에 쓰기
    BYTE buffer[1024];
    int nRead = 0;
    while ((nRead = file.Read(buffer, 1024)) > 0)
    {
        gzwrite(gzfile, buffer, nRead);
    }

    // 압축 파일 닫기
    gzclose(gzfile);
}

// CompressFile을 통해 20mb 미만 으로 압축 제한
#include <afx.h>
#include <zlib.h>

void CompressFile(CString strFilePath)
{
    // 압축할 파일 열기
    CFile file(strFilePath, CFile::modeRead);

    // 압축 파일 생성
    gzFile gzfile = gzopen("compressed.gz", "wb");

    // 데이터를 압축 파일에 쓰기
    BYTE buffer[1024];
    int nRead = 0;
    int nSize = 0;
    while ((nRead = file.Read(buffer, 1024)) > 0)
    {
        gzwrite(gzfile, buffer, nRead);
        nSize += nRead;
        if (nSize >= 20 * 1024 * 1024) // 20MB 제한
        {
            AfxMessageBox("압축 파일 크기가 20MB를 초과하였습니다.");
            break;
        }
    }

    // 압축 파일 닫기
    gzclose(gzfile);
}
