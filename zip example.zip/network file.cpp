// c++ tcp/ip를 이용한 File 전송 Client
#include <iostream>
#include <fstream>
#include <winsock2.h>

using namespace std;

#pragma comment(lib, "Ws2_32.lib")

int main() {
    WSADATA WSAData;
    SOCKET clientSocket;
    SOCKADDR_IN serverAddr;
    int serverAddrSize = sizeof(serverAddr);

    WSAStartup(MAKEWORD(2,0), &WSAData);

    clientSocket = socket(AF_INET, SOCK_STREAM, 0);

    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(8888);

    connect(clientSocket, (SOCKADDR *)&serverAddr, serverAddrSize);

    ifstream file("test.txt", ios::binary);
    if(!file) {
        cout << "File not found" << endl;
        closesocket(clientSocket);
        return 0;
    }

    char buffer[1024];
    while(!file.eof()) {
        file.read(buffer, 1024);
        int bytesRead = file.gcount();
        send(clientSocket, buffer, bytesRead, 0);
    }

    file.close();
    closesocket(clientSocket);

    cout << "File sent" << endl;

    WSACleanup();

    return 0;
}

// c++ tcp/ip를 이용한 File 전송 Server
#include <iostream>
#include <fstream>
#include <winsock2.h>

using namespace std;

#pragma comment(lib, "Ws2_32.lib")

int main() {
    WSADATA WSAData;
    SOCKET serverSocket, clientSocket;
    SOCKADDR_IN serverAddr, clientAddr;
    int clientAddrSize = sizeof(clientAddr);

    WSAStartup(MAKEWORD(2,0), &WSAData);

    serverSocket = socket(AF_INET, SOCK_STREAM, 0);

    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(8888);

    bind(serverSocket, (SOCKADDR *)&serverAddr, sizeof(serverAddr));
    listen(serverSocket, SOMAXCONN);

    cout << "Server started at port 8888" << endl;

    clientSocket = accept(serverSocket, (SOCKADDR *)&clientAddr, &clientAddrSize);

    char buffer[1024];
    ofstream file("received.txt", ios::binary);
    while(true) {
        int bytesReceived = recv(clientSocket, buffer, 1024, 0);
        if(bytesReceived <= 0)
            break;
        file.write(buffer, bytesReceived);
    }

    file.close();
    closesocket(clientSocket);
    closesocket(serverSocket);

    cout << "File received" << endl;

    WSACleanup();

    return 0;
}

// Cftpconnector 클래스를 이용하여 파일 다운 받기
#include <afxinet.h>

void DownloadFileFromFTP()
{
   CInternetSession session;
   CFtpConnection* pFtpConnection = session.GetFtpConnection(_T("ftp.example.com"), _T("username"), _T("password"), INTERNET_INVALID_PORT_NUMBER);

   if (pFtpConnection == NULL)
   {
      AfxMessageBox(_T("FTP 서버에 연결할 수 없습니다."));
      return;
   }

   CString strRemoteFileName = _T("/example.txt");
   CString strLocalFileName = _T("C:\\temp\\example.txt");
   CFile localFile;

   if (!localFile.Open(strLocalFileName, CFile::modeCreate | CFile::modeWrite))
   {
      AfxMessageBox(_T("로컬 파일을 열 수 없습니다."));
      return;
   }

   if (!pFtpConnection->GetFile(strRemoteFileName, localFile))
   {
      AfxMessageBox(_T("파일을 다운로드할 수 없습니다."));
   }

   localFile.Close();
   pFtpConnection->Close();
   delete pFtpConnection;
}

// transmitfile  함수를 사용한 서버 코드
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>

#define FILENAME "C:\\example.txt"
#define BUFFER_SIZE 1024

int main() {
    WSADATA wsaData;
    SOCKET serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    int clientAddrLen = sizeof(clientAddr);
    HANDLE fileHandle;
    char buffer[BUFFER_SIZE];
    DWORD bytesSent, fileSize;
    BOOL result;

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup failed with error: %d\n", WSAGetLastError());
        return 1;
    }

    // Create a socket
    serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (serverSocket == INVALID_SOCKET) {
        printf("socket failed with error: %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    // Bind the socket to a local address and port
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serverAddr.sin_port = htons(12345);
    if (bind(serverSocket, (struct sockaddr*) &serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        printf("bind failed with error: %d\n", WSAGetLastError());
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    // Listen for incoming connections
    if (listen(serverSocket, SOMAXCONN) == SOCKET_ERROR) {
        printf("listen failed with error: %d\n", WSAGetLastError());
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    // Accept an incoming connection
    clientSocket = accept(serverSocket, (struct sockaddr*) &clientAddr, &clientAddrLen);
    if (clientSocket == INVALID_SOCKET) {
        printf("accept failed with error: %d\n", WSAGetLastError());
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    // Open the file to be sent
    fileHandle = CreateFile(FILENAME, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (fileHandle == INVALID_HANDLE_VALUE) {
        printf("CreateFile failed with error: %d\n", GetLastError());
        closesocket(clientSocket);
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    // Get the size of the file
    fileSize = GetFileSize(fileHandle, NULL);

    // Send the file
    result = TransmitFile(clientSocket, fileHandle, fileSize, 0, NULL, NULL, TF_DISCONNECT | TF_REUSE_SOCKET);
    if (!result) {
        printf("TransmitFile failed with error: %d\n", WSAGetLastError());
    }

    // Close the file and socket
    CloseHandle(fileHandle);
    closesocket(clientSocket);
    closesocket(serverSocket);
    WSACleanup();

    return 0;
}

// transmitfile  함수를 사용한 클라이언트 코드
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>

#define SERVER_ADDRESS "127.0.0.1"
#define SERVER_PORT 12345
#define FILENAME "C:\\received.txt"
#define BUFFER_SIZE 1024

int main() {
    WSADATA wsaData;
    SOCKET clientSocket;
    struct sockaddr_in serverAddr;
    int serverAddrLen = sizeof(serverAddr);
    HANDLE fileHandle;
    char buffer[BUFFER_SIZE];
    DWORD bytesReceived, fileSize;
    BOOL result;

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup failed with error: %d\n", WSAGetLastError());
        return 1;
    }

    // Create a socket
    clientSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (clientSocket == INVALID_SOCKET) {
        printf("socket failed with error: %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    // Connect to the server
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(SERVER_ADDRESS);
    serverAddr.sin_port = htons(SERVER_PORT);
    if (connect(clientSocket, (struct sockaddr*) &serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        printf("connect failed with error: %d\n", WSAGetLastError());
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    // Create a file to store the received data
    fileHandle = CreateFile(FILENAME, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (fileHandle == INVALID_HANDLE_VALUE) {
        printf("CreateFile failed with error: %d\n", GetLastError());
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    // Receive the file
    result = TransmitFile(clientSocket, fileHandle, 0, 0, NULL, NULL, TF_DISCONNECT);
    if (!result) {
        printf("TransmitFile failed with error: %d\n", WSAGetLastError());
    }

    // Close the file and socket
    CloseHandle(fileHandle);
    closesocket(clientSocket);
    WSACleanup();

    return 0;
}

// // transmitfile  함수를 사용한 클라이언트 코드 2
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>

#define FILENAME "C:\\received.txt"
#define BUFFER_SIZE 1024

int main() {
    WSADATA wsaData;
    SOCKET clientSocket;
    struct sockaddr_in serverAddr;
    HANDLE fileHandle;
    char buffer[BUFFER_SIZE];
    DWORD bytesRead, fileSize;
    BOOL result;

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup failed with error: %d\n", WSAGetLastError());
        return 1;
    }

    // Create a socket
    clientSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (clientSocket == INVALID_SOCKET) {
        printf("socket failed with error: %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    // Connect to the server
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serverAddr.sin_port = htons(12345);
    if (connect(clientSocket, (struct sockaddr*) &serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        printf("connect failed with error: %d\n", WSAGetLastError());
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    // Create a file to store the received data
    fileHandle = CreateFile(FILENAME, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (fileHandle == INVALID_HANDLE_VALUE) {
        printf("CreateFile failed with error: %d\n", GetLastError());
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    // Receive the file
    do {
        result = recv(clientSocket, buffer, BUFFER_SIZE, 0);
        if (result > 0) {
            WriteFile(fileHandle, buffer, result, &bytesRead, NULL);
            fileSize += bytesRead;
        }
    } while (result > 0);

    if (result == SOCKET_ERROR) {
        printf("recv failed with error: %d\n", WSAGetLastError());
    }

    // Close the file and socket
    CloseHandle(fileHandle);
    closesocket(clientSocket);
    WSACleanup();

    return 0;
}
